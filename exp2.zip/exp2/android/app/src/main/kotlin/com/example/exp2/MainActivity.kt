package com.example.exp2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
